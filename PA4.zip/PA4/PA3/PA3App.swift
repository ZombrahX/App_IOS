//
//  PA3App.swift
//  PA3
//
//  Created by user269177 on 6/10/25.
//

import SwiftUI

@main
struct PA3App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
