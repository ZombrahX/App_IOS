//
//  PA3Tests.swift
//  PA3Tests
//
//  Created by user269177 on 6/10/25.
//

import Testing
@testable import PA3

struct PA3Tests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
